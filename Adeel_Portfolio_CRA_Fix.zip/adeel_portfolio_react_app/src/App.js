
import React from "react";

function App() {
  return (
    <div style={{ padding: "2rem" }}>
      <h1>Adeel Ahmad</h1>
      <p>Software Engineer | Sci-Fi Creator | Wormhole Visionary</p>
      <hr />
      <h2>🚀 Projects</h2>
      <ul>
        <li><a href="/downloads/Wormhole_Builder_Pitch_Kit_by_Adeel_Ahmad.zip">Download Full Pitch Kit</a></li>
        <li><a href="/downloads/Wormhole_Teaser_Trailer_Script.txt">Teaser Trailer Script</a></li>
        <li><a href="/downloads/Wormhole_Storyboard_With_Illustrations.pdf">Storyboard PDF</a></li>
        <li><a href="/downloads/one_page_pitch_summary.pdf">Pitch Summary</a></li>
      </ul>
    </div>
  );
}

export default App;
